let sidebarOpen = false;
let sidebarFrame = null;

// Lắng nghe lệnh từ background.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "toggle_sidebar") {
    toggleSidebar();
  }
});

function toggleSidebar() {
  if (sidebarOpen) {
    removeSidebar();
  } else {
    injectSidebar();
  }
  sidebarOpen = !sidebarOpen;
}

function injectSidebar() {
  if (document.getElementById('audit-sidebar-container')) return;

  // 1. Tạo container cho Sidebar
  const container = document.createElement('div');
  container.id = 'audit-sidebar-container';
  container.style.cssText = `
    position: fixed;
    top: 0;
    right: 0;
    width: 350px;
    height: 100vh;
    z-index: 999999;
    background: white;
    box-shadow: -5px 0 15px rgba(0,0,0,0.1);
    transition: transform 0.3s ease;
    border-left: 1px solid #e2e8f0;
  `;

  // 2. Tạo iframe chứa popup.html
  const iframe = document.createElement('iframe');
  iframe.src = chrome.runtime.getURL('popup.html');
  iframe.style.cssText = `
    width: 100%;
    height: 100%;
    border: none;
  `;
  
  container.appendChild(iframe);
  document.documentElement.appendChild(container);
  sidebarFrame = container;

  // 3. Co màn hình cuộc họp lại
  document.body.style.transition = 'width 0.3s ease';
  document.body.style.width = 'calc(100% - 350px)';
}

function removeSidebar() {
  if (sidebarFrame) {
    sidebarFrame.remove();
    sidebarFrame = null;
  }
  // Trả lại kích thước ban đầu
  document.body.style.width = '100%';
}
