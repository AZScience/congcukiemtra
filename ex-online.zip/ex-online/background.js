chrome.action.onClicked.addListener((tab) => {
  // Gửi tin nhắn tới content script của tab hiện tại để toggle sidebar
  chrome.tabs.sendMessage(tab.id, { action: "toggle_sidebar" });
});
