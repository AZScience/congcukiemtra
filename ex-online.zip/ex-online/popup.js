// Configuration
const API_BASE = "http://localhost:3000/api/v1"; // Địa chỉ Web App của bạn

document.addEventListener('DOMContentLoaded', async () => {
  const btnSearch = document.getElementById('btn-search');
  const btnStart = document.getElementById('btn-start');
  const btnEnd = document.getElementById('btn-end');
  const classCodeInput = document.getElementById('class-code');
  const statusMsg = document.getElementById('status-message');
  
  let currentClass = null;
  let startTime = null;
  let timerInterval = null;

  // 1. Tự động lấy link từ Tab hiện tại
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const currentTab = tabs[0];
    if (currentTab && currentTab.url && (currentTab.url.includes('meet.google.com') || currentTab.url.includes('zoom.us'))) {
      document.getElementById('meeting-link').value = currentTab.url;
    }
  });

  // 2. Tìm kiếm lớp học
  btnSearch.addEventListener('click', async () => {
    const code = classCodeInput.value.trim().toUpperCase();
    if (!code) return;

    showStatus("Đang tìm lớp...", "info");
    
    try {
      // Gọi API tìm lớp từ hệ thống chính
      // Lưu ý: Cần xử lý CORS trên Server nếu chạy local
      const response = await fetch(`${API_BASE}/schedules?class=${code}&date=${new Date().toISOString().split('T')[0]}`);
      const result = await response.json();
      
      if (result.success && result.data) {
        currentClass = result.data;
        displayClassInfo(currentClass);
        showStatus("Đã tìm thấy lớp!", "success");
      } else {
        showStatus("Không tìm thấy lớp học hôm nay.", "error");
      }
    } catch (err) {
      // Mock dữ liệu cho trường hợp chưa chạy API
      mockSearch(code);
    }
  });

  function mockSearch(code) {
    currentClass = {
        class: code,
        content: "Lớp học Online Test",
        lecturer: "Giảng viên Test",
        studentCount: 40
    };
    displayClassInfo(currentClass);
    showStatus("Dữ liệu mẫu (Hệ thống chưa kết nối API)", "info");
  }

  function displayClassInfo(info) {
    document.getElementById('info-course').textContent = info.content || "Chưa có tên môn";
    document.getElementById('info-class').textContent = info.class;
    document.getElementById('info-lecturer').textContent = info.lecturer;
    document.getElementById('class-info').classList.remove('hidden');
  }

  // 3. Bắt đầu tiết dạy (Login)
  btnStart.addEventListener('click', () => {
    startTime = new Date();
    btnStart.classList.add('hidden');
    btnEnd.classList.remove('hidden');
    document.getElementById('timer').classList.remove('hidden');
    
    startTimer();
    showStatus("Đã ghi nhận giờ bắt đầu (Login)", "success");
  });

  // 4. Kết thúc tiết dạy (Logout)
  btnEnd.addEventListener('click', async () => {
    const endTime = new Date();
    const studentCount = document.getElementById('student-count').value;
    const meetingLink = document.getElementById('meeting-link').value;

    if (!studentCount) {
      showStatus("Vui lòng nhập số sinh viên!", "error");
      return;
    }

    const reportData = {
      classId: currentClass.class,
      className: currentClass.content,
      lecturer: currentClass.lecturer,
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      studentCount: studentCount,
      meetingLink: meetingLink,
      status: 'completed',
      type: 'online'
    };

    try {
      showStatus("Đang gửi dữ liệu...", "info");
      
      const response = await fetch(`${API_BASE}/online-checkins`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reportData)
      });

      if (response.ok) {
        showStatus("Gửi báo cáo thành công!", "success");
        stopTimer();
        btnEnd.disabled = true;
      } else {
        throw new Error("Gửi thất bại");
      }
    } catch (err) {
      showStatus("Lỗi đồng bộ. Hãy lưu lại thông tin!", "error");
      console.error(err);
    }
  });

  function startTimer() {
    timerInterval = setInterval(() => {
      const now = new Date();
      const diff = now - startTime;
      const h = Math.floor(diff / 3600000).toString().padStart(2, '0');
      const m = Math.floor((diff % 3600000) / 60000).toString().padStart(2, '0');
      const s = Math.floor((diff % 60000) / 1000).toString().padStart(2, '0');
      document.getElementById('time-elapsed').textContent = `${h}:${m}:${s}`;
    }, 1000);
  }

  function stopTimer() {
    clearInterval(timerInterval);
  }

  function showStatus(msg, type) {
    statusMsg.textContent = msg;
    statusMsg.className = `status ${type}`;
  }
});
